//scan
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int i, j, k, n, m, seek = 0,h;
    cout << "Size of disk: ";
    cin >> m;
    cout << "Number of requests: ";
    cin >> n;
    int requests[n + 3];
    cout << "Enter the requests: \n";
    for (i = 0; i < n; i++)
    {
        cin >> requests[i];
    }
    cout << "Enter the head position: ";
    cin >> h;
    int temp = h;
    int size = n + 3;
    requests[n] = h;
    requests[n + 1] = m - 1;
    requests[n + 2] = 0;
    sort(requests, requests + size);
    for (i = 0; i < size; i++)
    {
        if (h == requests[i])
            break;
    }
    k = i;
    for (i = k; i < size; i++)
    {
        cout << "->" << requests[i];
    }
    seek = seek + (m - 1 - h);
    for (i = k - 1; i >= 0; i--)
    {
        cout << "->" << requests[i];
    }
    seek = seek + (m - 1);
    cout << endl
         << "Total seek time: " << seek << endl;
    return 0;
}
