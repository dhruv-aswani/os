//fcfs
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int i, n, m, seek = 0, h;
    cout << "Size of disk: ";
    cin >> m;
    cout << "Number of requests: ";
    cin >> n;
    vector<int> requests(n);
    cout << "Enter the requests: \n";
    for (i = 0; i < n; i++)
    {
        cin >> requests[i];
    }
    cout << "Enter the head position: ";
    cin >> h;
    requests.push_back(h);
    n++;
    cout << h;
    for (i = 0; i < n - 1; i++)
    {
        cout << "->" << requests[i];
        seek += abs(h - requests[i]);
        h = requests[i];
    }
    cout << endl
         << "Total seek time: " << seek << endl;
    return 0;
}
