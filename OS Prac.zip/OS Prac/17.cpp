#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n,m;
    cout << "Enter number of processes: ";
    cin >> n;
    cout << "Enter number of resources: ";
    cin >> m;

    int allocated[n][m], max[n][m], available[m];
    cout << "Enter Allocated Array: " << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> allocated[i][j];
        }
    }
    cout << "Enter Max Array: " << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> max[i][j];
        }
    }
    cout << "Enter Available Array: " << endl;
    for (int i = 0; i < m; i++)
    {
        cin >> available[i];
    }

    int need[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            need[i][j] = max[i][j] - allocated[i][j];
        }
    }

    cout << "Need Array: " << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cout << need[i][j] << " ";
        }
        cout << endl;
    }

    bool marked[n];
    for (int i = 0; i < n; i++)
    {
        marked[i] = false;
    }

    int safe_sequence[n];
    int safe_sequence_index = 0, resourceTypeAvailable;

    for (int i = 0; i < n; i++)
    {
        for (int p = 0; p < n; p++)
        {
            resourceTypeAvailable = 0;
            for (int j = 0; j < m; j++)
            {
                if (need[p][j] <= available[j])
                {
                    resourceTypeAvailable++;
                }
            }
            if (!marked[p] && resourceTypeAvailable == m)
            {
                safe_sequence[safe_sequence_index] = p;
                safe_sequence_index++;
                for (int j = 0; j < m; j++)
                {
                    available[j] += allocated[p][j];
                    need[p][j] = 0;
                    allocated[p][j] = 0;
                }
                marked[p] = true;
            }
        }
    }

    if (safe_sequence_index < n - 1)
    {
        cout << "The system is not in a safe state." << endl;
    }
    else
    {
        cout << "The system is in a safe state. The safe sequence is: ";
        for (int i = 0; i < safe_sequence_index; i++)
        {
            cout << "P" << safe_sequence[i] + 1 << " ";
        }
        cout << endl;
    }

    return 0;
}