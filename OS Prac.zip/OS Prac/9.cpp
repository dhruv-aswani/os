//LRU
#include <iostream>
using namespace std;

int main() {
    int i, j, k, min, ref_string[25], frame[10], count[10], flag[25], n, f, pf = 0, next = 0;
    cout << "Enter the length of the reference string: ";
    cin >> n;
    cout << "Enter the reference string: ";
    for (i = 0; i < n; i++) {
        cin >> ref_string[i];
        flag[i] = 0;
    }
    cout << "Enter the number of frames: ";
    cin >> f;
    for (i = 0; i < f; i++) {
        count[i] = 0;
        frame[i] = -1;
    }
    cout << "\nThe Page Replacement process is" << endl;
    for (i = 0; i < n; i++) {
        for (j = 0; j < f; j++) {
            if (frame[j] == ref_string[i]) { // pg Hit
                flag[i] = 1;
                count[j] = next;
                next++;
            }
        }
        if (flag[i] == 0) { // Miss
            if (i < f) { // no replace needed
                frame[i] = ref_string[i];
                count[i] = next;
                next++;
            } else { // LRU applied
                min = 0;
                for (j = 0; j < f; j++) {
                    if (count[min] > count[j])
                        min = j;
                }
                frame[min] = ref_string[i];
                count[min] = next;
                next++;
            }
            pf++;
        }
        for (j = 0; j < f; j++)
            cout << frame[j] << "\t";
        if (flag[i] == 0)
            cout << "Page Fault";
        else
            cout << "Page Hit";
        cout << endl;
    }
    cout << "\nThe number of page faults are " << pf << endl;
    cout << "The number of page Hits are " << n - pf << endl;
    cout << "The Hit ratio is " << n - pf << " / " << n << endl;
    return 0;
}
