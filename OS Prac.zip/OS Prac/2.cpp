//sjf
#include<bits/stdc++.h>
#include<algorithm>
using namespace std;

struct Process {
    int pid;
    int at;
    int bt;
};

bool cmp(Process a, Process b)
{
    return a.bt < b.bt;
}

void findWaitingTime(Process proc[], int n, int wt[])
{ 
    int rt[n];

    for (int i = 0; i < n; i++)
        rt[i] = proc[i].bt;

    int complete = 0, t = 0, minm = INT_MAX, shortest = 0, finish_time;

    bool check = false;

    while (complete != n) {

        for (int j = 0; j < n; j++) {
            if ((proc[j].at <= t) && (rt[j] < minm) && (rt[j] > 0)) {
                minm = rt[j];
                shortest = j;
                check = true;
            }
        }

        if (check == false) {
            t++;
            continue;
        }

        rt[shortest]--;

        minm = rt[shortest];

        if (minm == 0)
            minm = INT_MAX;

        if (rt[shortest] == 0) {

            complete++;

            finish_time = t + 1;

            wt[shortest] = finish_time - proc[shortest].bt - proc[shortest].at;

            if (wt[shortest] < 0)
                wt[shortest] = 0;
        }

        t++;
    }
}

void findTurnAroundTime(Process proc[], int n, int wt[], int tat[])
{
    for (int i = 0; i < n; i++)
        tat[i] = proc[i].bt + wt[i];
}

void findAvgTime(Process proc[], int n)
{
    int wt[n], tat[n], total_wt = 0, total_tat = 0;

    sort(proc, proc + n, cmp);

    findWaitingTime(proc, n, wt);

    findTurnAroundTime(proc, n, wt, tat);

    cout << "Processes " << " Burst time " << " Arrival time " << " Waiting time " << " Turn around time\n";

    for (int i = 0; i < n; i++) {
        total_wt = total_wt + wt[i];
        total_tat = total_tat + tat[i];
        cout << " " << proc[i].pid << "\t\t" << proc[i].bt << "\t\t" << proc[i].at << "\t\t " << wt[i] << "\t\t " << tat[i] << endl;
    }

    cout << "Average waiting time = " << (float)total_wt / (float)n;
    cout << "\nAverage turn around time = " << (float)total_tat / (float)n;
}

int main()
{
    int n;
    cout << "Enter the number of processes: ";
    cin >> n;

    Process proc[n];
    cout << "Enter the arrival time and burst time of each process:\n";
    for (int i = 0; i < n; i++) {
        cout << "Process " << i + 1 << ": ";
        proc[i].pid = i + 1;
        cin >> proc[i].at >> proc[i].bt;
    }

    findAvgTime(proc, n);

    return 0;
}
