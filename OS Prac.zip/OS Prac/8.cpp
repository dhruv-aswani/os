//FIFO
#include <iostream>
using namespace std;

int main() {
    int i, j, k, ref_string[25], pg_frame[10], flag[25], n, no_frames, hit = 0, pf = 0, front = 0, rear = -1;
    cout << "Enter the length of the reference string: ";
    cin >> n;
    cout << "Enter the reference string: ";
    for (i = 0; i < n; i++) {
        cin >> ref_string[i];
        flag[i] = 0;
    }
    cout << "Enter the number of frames: ";
    cin >> no_frames;
    for (i = 0; i < no_frames; i++) {
        pg_frame[i] = -1;
    }
    cout << "\nThe Page Replacement process is" << endl;
    for (i = 0; i < n; i++) {
        for (j = 0; j < no_frames; j++) {
            if (pg_frame[j] == ref_string[i]) { // pg Hit
                flag[i] = 1;
                hit++;
            }
        }
        if (flag[i] == 0) { // Miss
            if (rear < no_frames - 1) { // no replace needed
                rear++;
                pg_frame[rear] = ref_string[i];
            } else { // FIFO policy
                front = 0;
                pg_frame[front] = ref_string[i];
                front = (front + 1) % no_frames;
            }
            pf++;
        }
        for (j = 0; j < no_frames; j++)
            cout << pg_frame[j] << "\t";
        if (flag[i] == 0)
            cout << "Page Fault";
        else
            cout << "Page Hit";
        cout << endl;
    }
    cout << "\nThe number of page faults are " << pf << endl;
    cout << "The number of page Hits are " << hit << endl;
    cout << "The Hit ratio is " << hit << " / " << n << endl;
    return 0;
}
