//Best Fit
#include <iostream>
using namespace std;

int main() {
    int n, m;
    cout << "Enter number of memory blocks: ";
    cin >> n;
    int memory[n];
    cout << "Enter size of each memory block: ";
    for (int i = 0; i < n; i++) {
        cin >> memory[i];
    }
    cout << "Enter number of processes: ";
    cin >> m;
    int process[m];
    cout << "Enter size of each process: ";
    for (int i = 0; i < m; i++) {
        cin >> process[i];
    }
    int allocation[m];
    for (int i = 0; i < m; i++) {
        allocation[i] = -1;
    }
    for (int i = 0; i < m; i++) {
        int best_block = -1;
        for (int j = 0; j < n; j++) {
            if (memory[j] >= process[i]) {
                if (best_block == -1 || memory[j] < memory[best_block]) {
                    best_block = j;
                }
            }
        }
        if (best_block != -1) {
            allocation[i] = best_block;
            memory[best_block] -= process[i];
        }
    }
    cout << "\nProcess No.\tProcess Size\tBlock No.\n";
    for (int i = 0; i < m; i++) {
        cout << i+1 << "\t\t\t\t" << process[i] << "\t\t\t\t";
        if (allocation[i] != -1) {
            cout << allocation[i]+1 << endl;
        }
        else {
            cout << "Not Allocated\n";
        }
    }
    return 0;
}
