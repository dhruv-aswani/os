//Optimal
#include <iostream>
using namespace std;

int main() {
    int i, j, k, max_dist, ref_string[25], frame[10], dist[10], flag[25], n, f, pf = 0, next = 0;
    cout << "Enter the length of the reference string: ";
    cin >> n;
    cout << "Enter the reference string: ";
    for (i = 0; i < n; i++) {
        cin >> ref_string[i];
        flag[i] = 0;
    }
    cout << "Enter the number of frames: ";
    cin >> f;
    for (i = 0; i < f; i++) {
        dist[i] = 0;
        frame[i] = -1;
    }
    cout << "\nThe Page Replacement process is" << endl;
    for (i = 0; i < n; i++) {
        for (j = 0; j < f; j++) {
            if (frame[j] == ref_string[i]) { // pg Hit
                flag[i] = 1;
            }
        }
        if (flag[i] == 0) { // Miss
            if (i < f) { // no replace needed
                frame[i] = ref_string[i];
            } else { // Optimal policy
                max_dist = -1;
                for (j = 0; j < f; j++) {
                    dist[j] = 0;
                    for (k = i + 1; k < n; k++) {
                        if (ref_string[k] == frame[j]) {
                            dist[j] = k - i;
                            break;
                        }
                    }
                    if (dist[j] == 0) {
                        max_dist = j;
                        break;
                    }
                    if (dist[j] > dist[max_dist]) {
                        max_dist = j;
                    }
                }
                frame[max_dist] = ref_string[i];
            }
            pf++;
        }
        for (j = 0; j < f; j++)
            cout << frame[j] << "\t";
        if (flag[i] == 0)
            cout << "Page Fault";
        else
            cout << "Page Hit";
        cout << endl;
    }
    cout << "\nThe number of page faults are " << pf << endl;
    cout << "The number of page Hits are " << n - pf << endl;
    cout << "The Hit ratio is " << n - pf << " / " << n << endl;
    return 0;
}
