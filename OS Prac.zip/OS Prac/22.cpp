//cscan
#include <bits/stdc++.h>
using namespace std;

int main() {
    int i, j, k, n, m, seek = 0,h;
    cout << "Size of disk: ";
    cin >> m;
    cout << "Number of requests: ";
    cin >> n;
    int a[n + 3];
    cout << "Enter the requests: \n";
    for (i = 0; i < n; i++) {
        cin >> a[i];
    }
    cout << "Enter the head position: ";
    cin >> h;
    int temp = h;
    int size = n + 3;
    a[n] = h;
    a[n + 1] = m - 1;
    a[n + 2] = 0;

    sort(a, a + size);

    for (i = 0; i < size; i++) {
        if (h == a[i])
            break;
    }
    k = i;

    for (i = k; i < size; i++) {
        cout << "->" << a[i];
    }
    seek = seek + (m - 1 - h);

    for (i = 0; i < k; i++) {
        cout << "->" << a[i];
    }
    seek = seek + (m - 1);

    cout << endl << "Total seek time: " << seek << endl;

    return 0;
}
