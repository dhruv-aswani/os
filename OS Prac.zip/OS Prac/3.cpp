//non-preemptive priority
#include <iostream>
#include <algorithm>

using namespace std;

struct Process {
    int pid;
    int burst_time;
    int priority;
    int waiting_time;
    int turnaround_time;
};

bool compare(Process a, Process b) {
    return a.priority < b.priority;
}

int main() {
    int n;
    cout << "Enter number of processes: ";
    cin >> n;
    
    Process processes[n];
    for(int i = 0; i < n; i++) {
        cout << "Enter burst time for process " << i+1 << ": ";
        cin >> processes[i].burst_time;
        cout << "Enter priority for process " << i+1 << ": ";
        cin >> processes[i].priority;
        processes[i].pid = i+1;
        processes[i].waiting_time = 0;
        processes[i].turnaround_time = 0;
    }
    
    sort(processes, processes+n, compare);

    int current_time = 0;
    float avg_waiting_time = 0;
    float avg_turnaround_time = 0;
    cout << endl << "Printing Execution sequence: ";
    for (int i = 0; i < n; i++) {
        Process &p = processes[i];
        p.waiting_time = current_time;
        current_time += p.burst_time;
        p.turnaround_time = p.waiting_time + p.burst_time;
        avg_waiting_time += p.waiting_time;
        avg_turnaround_time += p.turnaround_time;
        cout << "P" << p.pid << " ";
    }

    cout << endl << endl;
    cout << "PID\tBurst Time\tPriority\tWaiting Time\tTurnaround Time\n";
    for (int i = 0; i < n; i++) {
        Process p = processes[i];
        cout << p.pid << "\t\t\t" << p.burst_time << "\t\t\t" << p.priority << "\t\t\t" << p.waiting_time << "\t\t\t" << p.turnaround_time << endl;
    }

    avg_waiting_time /= n;
    avg_turnaround_time /= n;
    cout << endl << "Avg. waiting time: " << avg_waiting_time;
    cout << endl << "Avg. turnaround time: " << avg_turnaround_time;
    
    return 0;
}
