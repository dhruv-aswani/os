//paging
#include <bits/stdc++.h>
using namespace std;

int binaryToDecimal(int n)
{
    int num = n;
    int dec_value = 0;
    int base = 1;
    int temp = num;
    while (temp) {
        int last_digit = temp % 10;
        temp = temp / 10;
        dec_value += last_digit * base;
        base = base * 2;
    }
    return dec_value;
}
int main(){

	long sizeOfProcess, sizeOfPage, sizeOfMM;

	cout<<"Enter Size of process(KB): ";
	cin >> sizeOfProcess;
	sizeOfProcess *= 1024;
	
	cout << "Enter size of page(Bytes): ";
	cin >> sizeOfPage;
	
	cout << "Enter size of Main Memory(MB): ";
	cin >> sizeOfMM;
	sizeOfMM *= 1048576;
	
	int noOfFrames, noOfPages;
	
	noOfFrames = ceil( (float) sizeOfMM/sizeOfPage );
	noOfPages = ceil( (float) sizeOfProcess/sizeOfPage );
	cout << endl << "Frames: " << noOfFrames;
	cout<< endl << "No. of entries in page table: " << noOfPages;

	int noOfBitsInPA, noOfBitsInLA, noOfBitsInOffset, noOfBitsInPageNo;
	
	noOfBitsInPA = log(sizeOfMM) / log(2);
	cout << endl << "Bits in Physical address: " << noOfBitsInPA;

	noOfBitsInLA = log(sizeOfProcess) / log(2);
	cout << endl << "Bits in Logical address: " << noOfBitsInLA;

	noOfBitsInOffset = log(sizeOfPage) / log(2);
	noOfBitsInPageNo = noOfBitsInLA - noOfBitsInOffset;
	
	cout << endl << "Distribution: ";
	cout << endl << "Bits in Offset: " << noOfBitsInOffset;
	cout << endl << "Bits for Page No: " << noOfBitsInPageNo;
	
	vector<int> frameNo(noOfPages);
	vector<int> valid(noOfPages);
	
	cout << endl << "Enter Frame No. in page table: ";
	for (int i=0;i<noOfPages;i++){
		cin >> frameNo[i];
	}
	
	cout << endl << "Enter vaid bits in page table: ";
	for (int i=0;i<noOfPages;i++){
		cin >> valid[i];
	}
	
	string add;
	cout << endl << "Enter a logical address of page number to check valid or not:";
	cin >> add;
	
	string pnoInBits = "";
	for(int i=0;i<noOfBitsInPageNo;i++){
		pnoInBits += add[i];
	}
	
	int pno = binaryToDecimal(stoi(pnoInBits));
	
	if(valid[pno]==1){
		cout<<"Page is in memory";
	}
	else{
		cout<<"Page is not in memory";
	}
}