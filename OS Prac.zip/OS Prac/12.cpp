//mft
#include <iostream>
using namespace std;

int main() {
    int m, p, s, p1;
    int m1[4], i, f, f1 = 0, f2 = 0, fra1, fra2, s1;


    cout << "Enter the memory size: ";
    cin >> m;
    cout << "Enter the no of partitions: ";
    cin >> p;

    s = m / p;
    cout << "Each partition size is: " << s << endl;

    cout << "Enter the no of processes: ";
    cin >> p1;

    for(i = 0; i < p1; i++) {
        cout << "Enter the memory req for process " << i+1 << ": ";
        cin >> m1[i];

        if(m1[i] <= s) {
            cout << "Process is allocated in partition " << i+1 << endl;
            fra1 = s - m1[i];
            cout << "Internal fragmentation for process is: " << fra1 << endl;
            f1 += fra1;
        } else {
            cout << "Process not allocated in partition " << i+1 << endl;
            s1 = m1[i] - s;
            fra2 = s - s1;
            f2 += fra2;
            cout << "External fragmentation for partition is: " << fra2 << endl;
        }
    }

    cout << "Process\t\t\tmemory\t\t\tallocated memory" << endl;
    for(i = 0; i < p1; i++) {
        cout <<"\t"<< i+1 << "\t\t\t" << s << "\t\t\t\t" << m1[i] << endl;
    }

    f = f1 + f2;
    cout << "The total number of fragmentation is: " << f << endl;


    return 0;
}
