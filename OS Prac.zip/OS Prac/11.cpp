//mvt
#include <iostream>
using namespace std;

int main() {
    int os_m, nPage, total, pg[25];
    cout << "Enter total memory size: ";
    cin >> total;

    cout << "Enter memory for OS: ";
    cin >> os_m;

    cout << "Enter no. of pages: ";
    cin >> nPage;

    for(int i=0; i < nPage; i++) {
        cout << "Enter size of page[" << i+1 << "]: ";
        cin >> pg[i];
    }

    total = total - os_m;

    for(int i=0; i < nPage; i++) {
        if(total >= pg[i]) {
            cout << "\nAllocate page " << i+1;
            total = total - pg[i];
        } else {
            cout << "\nPage " << i+1 << " is not allocated due to insufficient memory.";
        }
    }

    cout << "\nExternal Fragmentation is: " << total << endl;

    return 0;
}
