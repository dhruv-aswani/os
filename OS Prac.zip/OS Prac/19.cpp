//sstf
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int i, j,n, m, seek = 0, h;
    cout << "Size of disk: ";
    cin >> m;
    cout << "Number of requests: ";
    cin >> n;
    int requests[n];
    cout << "Enter the requests: \n";
    for (i = 0; i < n; i++)
    {
        cin >> requests[i];
    }
    cout << "Enter the head position: ";
    cin >> h;
    int temp = h;
    int size = n;
    int visited[size] = {0};
    for (i = 0; i < size; i++)
    {
        int minDist = INT_MAX, minIndex = -1;
        for (j = 0; j < size; j++)
        {
            if (!visited[j])
            {
                int dist = abs(h - requests[j]);
                if (dist < minDist)
                {
                    minDist = dist;
                    minIndex = j;
                }
            }
        }
        visited[minIndex] = 1;
        seek += minDist;
        h = requests[minIndex];
        cout << "->" << h;
    }
    cout << endl
         << "Total seek time: " << seek << endl;
    return 0;
}
